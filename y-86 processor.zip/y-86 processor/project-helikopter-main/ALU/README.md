## ALU Control Inputs and Functionality

    Control 0 - ADD x and y

    Control 1 – Subtract y from x

    Control 2 – AND x and y

    Control 3 – XOR x and y

## RUN INSTRUCTIONS

### XOR

```bash
cd Xor
iverilog -o xor xor_test.v xor64x1.v
vvp xor
```

### AND

```bash
cd And
iverilog -o and and_test.v and64x1.v
vvp and
```

### ADD

```bash
cd Add
iverilog -o add add_test.v add64x1.v add1x1.v
vvp add
```

### SUB

```bash
cd Sub
iverilog -o sub sub_test.v ../Add/add1x1.v ../Add/add64x1.v sub64x1.v  not/not64x1.v
vvp sub
```

## ALU

```bash
cd ALU
iverilog -o alu alu_test.v alu.v
vvp alu
```
